#!/bin/bash

# This will test your TrainTarget.exe app in (LIA_RAL_TOPDIR)/LIA_SpkDet/TrainTarget
# compare the resulting test1.gmm with test1.validate.gmm (use ReadModel for instance)
../TrainTarget.exe --config ./TrainTarget.cfg